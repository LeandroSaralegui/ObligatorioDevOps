exports.handler = async (event) => {
  console.log("Evento recibido:", JSON.stringify(event));

  return {
    statusCode: 200,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*"
    },
    body: JSON.stringify({
      service: "retailstore-observability-status",
      environment: process.env.ENVIRONMENT,
      status: "ok",
      purpose: "serverless observability endpoint",
      architecture: "api-gateway-http-api-lambda",
      timestamp: new Date().toISOString()
    })
  };
};
